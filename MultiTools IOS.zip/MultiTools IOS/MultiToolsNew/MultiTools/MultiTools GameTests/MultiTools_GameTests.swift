//
//  MultiTools_GameTests.swift
//  MultiTools GameTests
//
//  Created by Fotini Konstantinidis on 6/19/25.
//

import Testing
@testable import MultiTools_Game

struct MultiTools_GameTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
