import SwiftUI

@main
struct MultiToolsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
