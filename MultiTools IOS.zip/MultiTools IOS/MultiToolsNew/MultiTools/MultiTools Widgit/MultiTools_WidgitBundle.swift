//
//  MultiTools_WidgitBundle.swift
//  MultiTools Widgit
//
//  Created by Fotini Konstantinidis on 6/19/25.
//

import WidgetKit
import SwiftUI

@main
struct MultiTools_WidgitBundle: WidgetBundle {
    var body: some Widget {
        MultiTools_Widgit()
        MultiTools_WidgitControl()
        MultiTools_WidgitLiveActivity()
    }
}
