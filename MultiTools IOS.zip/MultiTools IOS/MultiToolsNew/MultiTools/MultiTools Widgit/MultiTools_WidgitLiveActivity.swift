//
//  MultiTools_WidgitLiveActivity.swift
//  MultiTools Widgit
//
//  Created by Fotini Konstantinidis on 6/19/25.
//

import ActivityKit
import WidgetKit
import SwiftUI

struct MultiTools_WidgitAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        // Dynamic stateful properties about your activity go here!
        var emoji: String
    }

    // Fixed non-changing properties about your activity go here!
    var name: String
}

struct MultiTools_WidgitLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: MultiTools_WidgitAttributes.self) { context in
            // Lock screen/banner UI goes here
            VStack {
                Text("Hello \(context.state.emoji)")
            }
            .activityBackgroundTint(Color.cyan)
            .activitySystemActionForegroundColor(Color.black)

        } dynamicIsland: { context in
            DynamicIsland {
                // Expanded UI goes here.  Compose the expanded UI through
                // various regions, like leading/trailing/center/bottom
                DynamicIslandExpandedRegion(.leading) {
                    Text("Leading")
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text("Trailing")
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text("Bottom \(context.state.emoji)")
                    // more content
                }
            } compactLeading: {
                Text("L")
            } compactTrailing: {
                Text("T \(context.state.emoji)")
            } minimal: {
                Text(context.state.emoji)
            }
            .widgetURL(URL(string: "http://www.apple.com"))
            .keylineTint(Color.red)
        }
    }
}

extension MultiTools_WidgitAttributes {
    fileprivate static var preview: MultiTools_WidgitAttributes {
        MultiTools_WidgitAttributes(name: "World")
    }
}

extension MultiTools_WidgitAttributes.ContentState {
    fileprivate static var smiley: MultiTools_WidgitAttributes.ContentState {
        MultiTools_WidgitAttributes.ContentState(emoji: "😀")
     }
     
     fileprivate static var starEyes: MultiTools_WidgitAttributes.ContentState {
         MultiTools_WidgitAttributes.ContentState(emoji: "🤩")
     }
}

#Preview("Notification", as: .content, using: MultiTools_WidgitAttributes.preview) {
   MultiTools_WidgitLiveActivity()
} contentStates: {
    MultiTools_WidgitAttributes.ContentState.smiley
    MultiTools_WidgitAttributes.ContentState.starEyes
}
